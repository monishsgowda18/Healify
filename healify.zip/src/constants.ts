export const LANGUAGES = [
  { code: 'en', name: 'English', native: 'English', rtl: false },
  { code: 'hi', name: 'Hindi', native: 'हिन्दी', rtl: false },
  { code: 'bn', name: 'Bengali', native: 'বাংলা', rtl: false },
  { code: 'te', name: 'Telugu', native: 'తెలుగు', rtl: false },
  { code: 'mr', name: 'Marathi', native: 'मराठी', rtl: false },
  { code: 'ta', name: 'Tamil', native: 'தமிழ்', rtl: false },
  { code: 'ur', name: 'Urdu', native: 'اردو', rtl: true },
  { code: 'gu', name: 'Gujarati', native: 'ગુજરાતી', rtl: false },
  { code: 'kn', name: 'Kannada', native: 'ಕನ್ನಡ', rtl: false },
  { code: 'or', name: 'Odia', native: 'ଓଡ଼ିଆ', rtl: false },
  { code: 'ml', name: 'Malayalam', native: 'മലയാളം', rtl: false },
  { code: 'pa', name: 'Punjabi', native: 'ਪੰਜਾਬੀ', rtl: false },
  { code: 'ks', name: 'Kashmiri', native: 'कॉशुर', rtl: false },
  { code: 'ne', name: 'Nepali', native: 'नेपाली', rtl: false },
  { code: 'kok', name: 'Konkani', native: 'कोंकणी', rtl: false },
  { code: 'mni', name: 'Manipuri', native: 'মানিপুরী', rtl: false },
  { code: 'sa', name: 'Sanskrit', native: 'संस्कृतम्', rtl: false },
  // ... adding more as needed, but these cover the major ones requested
];

export const ROLES = [
  { id: 'patient', label: 'Patient', icon: 'User' },
  { id: 'doctor', label: 'Doctor', icon: 'Stethoscope' },
  { id: 'nurse', label: 'Nurse', icon: 'HeartPulse' },
  { id: 'pharmacy', label: 'Pharmacy Holder', icon: 'Pill' },
  { id: 'guardian', label: 'Guardian', icon: 'ShieldCheck' },
];
