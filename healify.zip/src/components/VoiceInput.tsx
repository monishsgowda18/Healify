import React, { useState } from 'react';
import { Mic, Loader2 } from 'lucide-react';
import { voiceService } from '../services/voiceService';
import { cn } from '../lib/utils';

interface VoiceInputProps {
  onResult: (text: string) => void;
  className?: string;
  size?: number;
}

export const VoiceInput: React.FC<VoiceInputProps> = ({ onResult, className, size = 20 }) => {
  const [isListening, setIsListening] = useState(false);

  const handleListen = async () => {
    setIsListening(true);
    try {
      const text = await voiceService.listen();
      onResult(text);
    } catch (error) {
      console.error('Voice input error:', error);
    } finally {
      setIsListening(false);
    }
  };

  return (
    <button
      type="button"
      onClick={handleListen}
      disabled={isListening}
      className={cn(
        "p-2 rounded-lg transition-all hover:bg-slate-100 text-slate-400 hover:text-teal-500 disabled:opacity-50",
        isListening && "text-teal-500 animate-pulse",
        className
      )}
      title="Voice Input"
    >
      {isListening ? (
        <Loader2 className={cn("animate-spin", `w-${size/4} h-${size/4}`)} style={{ width: size, height: size }} />
      ) : (
        <Mic className={cn(`w-${size/4} h-${size/4}`)} style={{ width: size, height: size }} />
      )}
    </button>
  );
};
