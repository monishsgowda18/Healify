import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserRole } from '../types';
import { storage } from '../services/storageService';

interface AuthContextType {
  user: User | null;
  login: (phone: string, role: UserRole) => Promise<void>;
  register: (userData: Partial<User>) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadUser = async () => {
      // Seed some data for demo if empty
      const users = await storage.getAll('users');
      if (users.length === 0) {
        const demoUser: User = {
          id: 'p123',
          name: 'Rahul Sharma',
          role: 'patient',
          language: 'en',
          contactNumber: '9876543210',
          isVerified: true,
          voiceAssistantEnabled: true,
          points: 450,
          badges: ['Medication Master', 'Hydration Hero']
        };
        const demoDoc: User = {
          id: 'd123',
          name: 'Dr. Anjali Gupta',
          role: 'doctor',
          language: 'en',
          contactNumber: '9998887776',
          isVerified: true,
          voiceAssistantEnabled: false,
          points: 0,
          badges: []
        };
        await storage.setItem('users', demoUser);
        await storage.setItem('users', demoDoc);

        // Seed some metrics
        await storage.setItem('metrics', { id: 'm1', userId: 'p123', type: 'weight', value: 72, unit: 'kg', timestamp: Date.now() - 86400000 });
        await storage.setItem('metrics', { id: 'm2', userId: 'p123', type: 'steps', value: 5400, unit: 'steps', timestamp: Date.now() - 43200000 });
        
        // Seed a prescription
        await storage.setItem('prescriptions', {
          id: 'pr1',
          patientId: 'p123',
          medications: [{ name: 'Paracetamol', dosage: '500mg', frequency: 'Twice daily', duration: '5 days' }],
          instructions: 'Take after meals. Drink plenty of water.',
          timestamp: Date.now() - 172800000,
          isAIGenerated: true,
          consultationId: 'c1'
        });
      }

      const savedUser = localStorage.getItem('healify_user');
      if (savedUser) {
        setUser(JSON.parse(savedUser));
      }
      setIsLoading(false);
    };
    loadUser();
  }, []);

  const login = async (phone: string, role: UserRole) => {
    // Mock login for demo
    const users = await storage.getAll('users');
    const foundUser = users.find(u => u.contactNumber === phone && u.role === role);
    
    if (foundUser) {
      setUser(foundUser);
      localStorage.setItem('healify_user', JSON.stringify(foundUser));
    } else {
      throw new Error('User not found');
    }
  };

  const register = async (userData: Partial<User>) => {
    const newUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      name: userData.name || '',
      role: userData.role || 'patient',
      language: userData.language || 'en',
      contactNumber: userData.contactNumber || '',
      isVerified: userData.role === 'patient' || userData.role === 'guardian',
      voiceAssistantEnabled: userData.voiceAssistantEnabled || false,
      points: 0,
      badges: [],
      ...userData
    };
    
    await storage.setItem('users', newUser);
    setUser(newUser);
    localStorage.setItem('healify_user', JSON.stringify(newUser));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('healify_user');
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
