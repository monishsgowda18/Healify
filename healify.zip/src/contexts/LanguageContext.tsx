import React, { createContext, useContext, useState, useEffect } from 'react';
import { LANGUAGES } from '../constants';

interface LanguageContextType {
  language: string;
  setLanguage: (lang: string) => void;
  isRTL: boolean;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// Simple translation map for demo
const translations: Record<string, Record<string, string>> = {
  en: {
    welcome: 'Welcome to Healify',
    select_language: 'Select Your Language',
    select_role: 'Who are you?',
    login: 'Login',
    register: 'Register',
    logout: 'Log Out',
    home: 'Home',
    ai_chat: 'AI Counseling',
    health_tracker: 'Health Tracker',
    prescriptions: 'Prescriptions',
    medical_library: 'Medical Library',
    settings: 'Settings',
    heart_rate: 'Heart Rate',
    guardian_portal: 'Guardian Portal',
    request_consultation: 'Request Consultation',
    active_alerts: 'Active Health Alerts',
    confirm_logout: 'Are you sure you want to log out?',
    cancel: 'Cancel',
    confirm: 'Confirm',
  },
  hi: {
    welcome: 'हीलीफाई में आपका स्वागत है',
    select_language: 'अपनी भाषा चुनें',
    select_role: 'आप कौन हैं?',
    login: 'लॉगिन',
    register: 'पंजीकरण',
    logout: 'लॉग आउट',
    home: 'होम',
    ai_chat: 'एआई परामर्श',
    health_tracker: 'स्वास्थ्य ट्रैकर',
    prescriptions: 'नुस्खे',
    medical_library: 'चिकित्सा पुस्तकालय',
    settings: 'सेटिंग्स',
    heart_rate: 'हृदय गति',
    guardian_portal: 'अभिभावक पोर्टल',
    request_consultation: 'परामर्श का अनुरोध करें',
    active_alerts: 'सक्रिय स्वास्थ्य अलर्ट',
    confirm_logout: 'क्या आप वाकई लॉग आउट करना चाहते हैं?',
    cancel: 'रद्द करें',
    confirm: 'पुष्टि करें',
  },
  ur: {
    welcome: 'ہیلی فائی میں خوش آمدید',
    select_language: 'اپنی زبان منتخب کریں',
    select_role: 'آپ کون ہیں؟',
    login: 'لاگ ان کریں',
    register: 'رجسٹر کریں',
    logout: 'لاگ آؤٹ',
    home: 'ہوم',
    ai_chat: 'AI مشاورت',
    health_tracker: 'ہیلتھ ٹریکر',
    prescriptions: 'نسخے',
    medical_library: 'میڈیکل لائبریری',
    settings: 'سیٹنگز',
    heart_rate: 'دل کی دھڑکن',
    guardian_portal: 'گارڈین پورٹل',
    request_consultation: 'مشاورت کی درخواست کریں',
    active_alerts: 'فعال صحت کے الرٹس',
    confirm_logout: 'کیا آپ واقعی لاگ آؤٹ کرنا چاہتے ہیں؟',
    cancel: 'منسوخ کریں',
    confirm: 'تصدیق کریں',
  }
};

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState('en');
  const [isRTL, setIsRTL] = useState(false);

  useEffect(() => {
    const savedLang = localStorage.getItem('healify_lang');
    if (savedLang) {
      setLanguage(savedLang);
    }
  }, []);

  const setLanguage = (lang: string) => {
    setLanguageState(lang);
    const langConfig = LANGUAGES.find(l => l.code === lang);
    setIsRTL(langConfig?.rtl || false);
    localStorage.setItem('healify_lang', lang);
    document.dir = langConfig?.rtl ? 'rtl' : 'ltr';
  };

  const t = (key: string) => {
    return translations[language]?.[key] || translations['en'][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, isRTL, t }}>
      <div className={isRTL ? 'font-urdu' : 'font-sans'}>
        {children}
      </div>
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) throw new Error('useLanguage must be used within LanguageProvider');
  return context;
};
