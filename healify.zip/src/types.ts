export type UserRole = 'patient' | 'doctor' | 'nurse' | 'pharmacy' | 'guardian';

export interface User {
  id: string;
  name: string;
  role: UserRole;
  language: string;
  age?: number;
  gender?: string;
  location?: string;
  contactNumber: string;
  isVerified: boolean;
  guardianId?: string;
  guardians?: GuardianDetail[];
  voiceAssistantEnabled: boolean;
  points: number;
  badges: string[];
}

export interface GuardianDetail {
  id: string;
  name: string;
  relationship: string;
  contactNumber: string;
  isEmergencyContact: boolean;
}

export interface HealthFile {
  id: string;
  userId: string;
  name: string;
  type: string;
  url: string;
  timestamp: number;
}

export interface HealthMetric {
  id: string;
  userId: string;
  type: 'weight' | 'blood_sugar' | 'temperature' | 'steps' | 'sleep';
  value: number;
  unit: string;
  timestamp: number;
}

export interface Consultation {
  id: string;
  patientId: string;
  doctorId?: string;
  status: 'pending' | 'in-progress' | 'completed';
  symptoms: string;
  vitals: Partial<Record<HealthMetric['type'], number>>;
  images: string[]; // base64
  diagnosis?: string;
  prescription?: Medication[];
  instructions?: string;
  doctorNotes?: string;
  timestamp: number;
}

export interface Prescription {
  id: string;
  consultationId: string;
  patientId: string;
  medications: Medication[];
  instructions: string;
  timestamp: number;
  isAIGenerated: boolean;
}

export interface Medication {
  name: string;
  dosage: string;
  frequency: string;
  duration: string;
  alternatives?: string[];
}
