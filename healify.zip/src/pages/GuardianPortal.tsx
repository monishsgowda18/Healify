import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { motion } from 'motion/react';
import { 
  Users, 
  Plus, 
  ArrowLeft, 
  Shield, 
  Phone, 
  UserPlus,
  Trash2,
  Heart,
  Mic
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { storage } from '../services/storageService';
import { GuardianDetail } from '../types';
import { cn } from '../lib/utils';
import { VoiceInput } from '../components/VoiceInput';

export default function GuardianPortal() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [guardians, setGuardians] = useState<GuardianDetail[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newGuardian, setNewGuardian] = useState({
    name: '',
    relationship: '',
    contactNumber: '',
    isEmergencyContact: false
  });

  useEffect(() => {
    fetchGuardians();
  }, [user]);

  const fetchGuardians = async () => {
    const all = await storage.getAll('guardians');
    setGuardians(all.filter(g => true)); // In a real app, filter by userId if stored
  };

  const handleVoiceResult = (field: string, text: string) => {
    setNewGuardian(prev => ({ ...prev, [field]: text }));
  };

  const handleAddGuardian = async () => {
    if (!newGuardian.name || !newGuardian.contactNumber) return;
    
    const guardian: GuardianDetail = {
      id: Date.now().toString(),
      ...newGuardian
    };

    await storage.setItem('guardians', guardian);
    setShowAddModal(false);
    setNewGuardian({ name: '', relationship: '', contactNumber: '', isEmergencyContact: false });
    fetchGuardians();
  };

  const handleDelete = async (id: string) => {
    await storage.deleteItem('guardians', id);
    fetchGuardians();
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-white rounded-xl shadow-sm">
            <ArrowLeft className="w-6 h-6 text-slate-600" />
          </button>
          <h1 className="text-3xl font-bold text-slate-800">Guardian Portal</h1>
        </div>
        <button 
          onClick={() => setShowAddModal(true)}
          className="bg-teal-500 text-white px-6 py-3 rounded-2xl font-bold flex items-center gap-2 shadow-lg shadow-teal-200"
        >
          <UserPlus className="w-5 h-5" /> Add Guardian
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {guardians.length > 0 ? guardians.map((guardian) => (
          <motion.div 
            key={guardian.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white p-6 rounded-[32px] shadow-sm border border-slate-100 relative group"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-slate-50 rounded-2xl flex items-center justify-center">
                  <Users className="w-7 h-7 text-slate-400" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-800">{guardian.name}</h3>
                  <p className="text-slate-500 text-sm font-medium">{guardian.relationship}</p>
                </div>
              </div>
              {guardian.isEmergencyContact && (
                <div className="bg-red-50 text-red-600 px-3 py-1 rounded-full text-[10px] font-bold uppercase flex items-center gap-1">
                  <Shield className="w-3 h-3" /> Emergency
                </div>
              )}
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-3 text-slate-600 bg-slate-50 p-3 rounded-xl">
                <Phone className="w-4 h-4 text-slate-400" />
                <span className="text-sm font-medium">{guardian.contactNumber}</span>
              </div>
            </div>

            <div className="mt-6 flex gap-2">
              <button className="flex-1 py-3 bg-teal-50 text-teal-600 rounded-xl font-bold text-sm hover:bg-teal-100 transition-colors">
                Call Now
              </button>
              <button 
                onClick={() => handleDelete(guardian.id)}
                className="p-3 text-slate-300 hover:text-red-500 transition-colors"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
          </motion.div>
        )) : (
          <div className="col-span-full py-20 text-center bg-white rounded-[40px] border border-slate-100">
            <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="w-10 h-10 text-slate-300" />
            </div>
            <h3 className="text-xl font-bold text-slate-800">No guardians added</h3>
            <p className="text-slate-500 mt-2">Add family members who can assist you in emergencies.</p>
          </div>
        )}
      </div>

      {/* Add Guardian Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-[40px] p-8 max-w-md w-full shadow-2xl"
          >
            <h3 className="text-2xl font-bold text-slate-800 mb-6">Add Family Member</h3>
            <div className="space-y-4">
              <div className="relative">
                <label className="block text-sm font-medium text-slate-700 mb-2">Full Name</label>
                <div className="relative">
                  <input
                    type="text"
                    className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:border-teal-500 outline-none font-bold pr-14"
                    placeholder="e.g. Rahul Sharma"
                    value={newGuardian.name}
                    onChange={e => setNewGuardian({...newGuardian, name: e.target.value})}
                  />
                  <VoiceInput 
                    onResult={(text) => handleVoiceResult('name', text)} 
                    className="absolute right-3 top-2.5"
                    size={24}
                  />
                </div>
              </div>
              <div className="relative">
                <label className="block text-sm font-medium text-slate-700 mb-2">Relationship</label>
                <div className="relative">
                  <input
                    type="text"
                    className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:border-teal-500 outline-none font-bold pr-14"
                    placeholder="e.g. Father, Spouse"
                    value={newGuardian.relationship}
                    onChange={e => setNewGuardian({...newGuardian, relationship: e.target.value})}
                  />
                  <VoiceInput 
                    onResult={(text) => handleVoiceResult('relationship', text)} 
                    className="absolute right-3 top-2.5"
                    size={24}
                  />
                </div>
              </div>
              <div className="relative">
                <label className="block text-sm font-medium text-slate-700 mb-2">Contact Number</label>
                <div className="relative">
                  <input
                    type="tel"
                    className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:border-teal-500 outline-none font-bold pr-14"
                    placeholder="+91 XXXXX XXXXX"
                    value={newGuardian.contactNumber}
                    onChange={e => setNewGuardian({...newGuardian, contactNumber: e.target.value})}
                  />
                  <VoiceInput 
                    onResult={(text) => handleVoiceResult('contactNumber', text.replace(/\s/g, ''))} 
                    className="absolute right-3 top-2.5"
                    size={24}
                  />
                </div>
              </div>
              <label className="flex items-center gap-3 p-4 bg-slate-50 rounded-2xl cursor-pointer">
                <input 
                  type="checkbox" 
                  className="w-5 h-5 rounded-lg border-slate-300 text-teal-500 focus:ring-teal-500"
                  checked={newGuardian.isEmergencyContact}
                  onChange={e => setNewGuardian({...newGuardian, isEmergencyContact: e.target.checked})}
                />
                <span className="text-sm font-bold text-slate-700">Set as Emergency Contact</span>
              </label>
            </div>
            <div className="flex gap-3 mt-8">
              <button 
                onClick={() => setShowAddModal(false)}
                className="flex-1 py-4 rounded-2xl font-bold text-slate-500 hover:bg-slate-50"
              >
                Cancel
              </button>
              <button 
                onClick={handleAddGuardian}
                className="flex-1 py-4 rounded-2xl bg-teal-500 text-white font-bold shadow-lg shadow-teal-200 hover:bg-teal-600"
              >
                Save Guardian
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
