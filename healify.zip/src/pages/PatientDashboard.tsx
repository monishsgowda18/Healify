import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { motion } from 'motion/react';
import { 
  PlusCircle, MessageSquare, Activity, Pill, BookOpen, Heart, 
  ArrowUpRight, Clock, AlertCircle, ShieldAlert, Users, 
  Lightbulb, TrendingUp, Share2, Download
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { storage } from '../services/storageService';
import { HealthMetric, Consultation, GuardianDetail } from '../types';
import { cn } from '../lib/utils';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

export default function PatientDashboard() {
  const { user } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [metrics, setMetrics] = useState<HealthMetric[]>([]);
  const [consultations, setConsultations] = useState<Consultation[]>([]);
  const [guardians, setGuardians] = useState<GuardianDetail[]>([]);
  const [isSOSActive, setIsSOSActive] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      const allMetrics = await storage.getAll('metrics');
      setMetrics(allMetrics.filter(m => m.userId === user?.id).slice(-5));
      const allCons = await storage.getAll('consultations');
      setConsultations(allCons.filter(c => c.patientId === user?.id));
      const allGuardians = await storage.getAll('guardians');
      setGuardians(allGuardians.filter(g => g.isEmergencyContact));
    };
    fetchData();
  }, [user]);

  const handleSOS = () => {
    setIsSOSActive(true);
    // Simulate SMS alert
    setTimeout(() => {
      alert(`EMERGENCY ALERT SENT!\nTo: ${guardians.map(g => g.name).join(', ') || 'Nearest Hospital'}\nLocation: 12.9716° N, 77.5946° E\nVitals: ${metrics.map(m => `${m.type}: ${m.value}${m.unit}`).join(', ')}`);
      setIsSOSActive(false);
    }, 2000);
  };

  const cards = [
    { title: t('request_consultation'), icon: PlusCircle, color: 'bg-teal-50 text-teal-600', path: '/consultation/new', desc: 'Connect with a doctor' },
    { title: t('ai_chat'), icon: MessageSquare, color: 'bg-purple-50 text-purple-600', path: '/ai-chat', desc: 'Instant medical guidance' },
    { title: t('prescriptions'), icon: Pill, color: 'bg-orange-50 text-orange-600', path: '/prescriptions', desc: 'View your medications' },
    { title: t('health_tracker'), icon: Activity, color: 'bg-blue-50 text-blue-600', path: '/tracker', desc: 'Log your vitals' },
    { title: 'Guardian Portal', icon: Users, color: 'bg-indigo-50 text-indigo-600', path: '/guardians', desc: 'Manage family members' },
    { title: t('medical_library'), icon: BookOpen, color: 'bg-slate-50 text-slate-600', path: '/library', desc: 'Health knowledge base' },
  ];

  const analyticsData = [
    { name: 'Consultations', value: consultations.length },
    { name: 'Prescriptions', value: consultations.filter(c => c.status === 'completed').length },
    { name: 'Vitals Logged', value: metrics.length },
  ];

  const healthTips = [
    "Drink at least 8 glasses of water daily for better hydration.",
    "Wash your hands thoroughly before every meal to prevent infections.",
    "Include seasonal fruits in your diet for essential vitamins.",
    "A 20-minute walk daily can significantly improve heart health."
  ];

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-8">
      {/* SOS & Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">Namaste, {user?.name}</h1>
          <p className="text-slate-500">How are you feeling today?</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={handleSOS}
            disabled={isSOSActive}
            className={cn(
              "flex items-center gap-2 px-8 py-4 rounded-2xl font-black text-lg shadow-2xl transition-all active:scale-95",
              isSOSActive ? "bg-slate-200 text-slate-400" : "bg-red-600 text-white hover:bg-red-700 shadow-red-200 animate-pulse"
            )}
          >
            <ShieldAlert className="w-6 h-6" />
            {isSOSActive ? "SENDING..." : "EMERGENCY SOS"}
          </button>
          <div className="hidden sm:flex bg-white px-4 py-2 rounded-2xl shadow-sm border border-slate-100 items-center gap-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            <span className="text-sm font-medium text-slate-600">Offline Mode Ready</span>
          </div>
        </div>
      </div>

      {/* Gamified Progress */}
      <div className="bg-gradient-to-r from-teal-500 to-emerald-600 rounded-[40px] p-8 text-white shadow-xl shadow-teal-100 relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-8">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-md">
                <TrendingUp className="w-7 h-7" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">Health Warrior Level 4</h2>
                <p className="text-teal-50 opacity-90 text-sm">You've completed 85% of your weekly goals!</p>
              </div>
            </div>
            <div className="w-full h-4 bg-white/20 rounded-full overflow-hidden backdrop-blur-sm">
              <motion.div 
                initial={{ width: 0 }} 
                animate={{ width: '85%' }} 
                className="h-full bg-white shadow-[0_0_15px_rgba(255,255,255,0.6)] rounded-full relative"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer" />
              </motion.div>
            </div>
          </div>
          <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
            {[
              { icon: '🏆', label: 'Medication Master', color: 'bg-white/10' },
              { icon: '💧', label: 'Hydration Hero', color: 'bg-white/10' },
              { icon: '🏃', label: 'Early Bird', color: 'bg-white/10' },
            ].map((badge, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.1 }}
                className={cn("flex-shrink-0 px-5 py-4 rounded-2xl flex flex-col items-center gap-2 min-w-[100px] backdrop-blur-md border border-white/20", badge.color)}
              >
                <span className="text-2xl">{badge.icon}</span>
                <span className="text-[10px] font-black uppercase tracking-wider text-center">{badge.label}</span>
              </motion.div>
            ))}
          </div>
        </div>
        <div className="absolute -right-10 -bottom-10 w-60 h-60 bg-white/10 rounded-full blur-3xl" />
        <div className="absolute -left-10 -top-10 w-40 h-40 bg-emerald-400/20 rounded-full blur-2xl" />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {cards.map((card, idx) => (
          <motion.button key={card.title} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.05 }} onClick={() => navigate(card.path)} className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 hover:shadow-md hover:border-teal-200 transition-all text-left group">
            <div className={cn("w-14 h-14 rounded-2xl flex items-center justify-center mb-4 transition-transform group-hover:scale-110", card.color)}><card.icon className="w-7 h-7" /></div>
            <div className="flex items-center justify-between"><h3 className="text-xl font-bold text-slate-800">{card.title}</h3><ArrowUpRight className="w-5 h-5 text-slate-300 group-hover:text-teal-500 transition-colors" /></div>
            <p className="text-slate-500 mt-1">{card.desc}</p>
          </motion.button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Analytics Dashboard */}
        <div className="lg:col-span-2 bg-white p-8 rounded-[40px] shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h3 className="text-xl font-bold text-slate-800">Health Analytics</h3>
              <p className="text-slate-400 text-sm">Your activity overview</p>
            </div>
            <button className="p-2 hover:bg-slate-50 rounded-xl text-slate-400"><Download className="w-5 h-5" /></button>
          </div>
          <div className="h-[250px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analyticsData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <Tooltip cursor={{fill: '#f8fafc'}} contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'}} />
                <Bar dataKey="value" radius={[10, 10, 0, 0]} barSize={40}>
                  {analyticsData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={['#14b8a6', '#a855f7', '#3b82f6'][index % 3]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Health Tips */}
        <div className="bg-teal-50 p-8 rounded-[40px] border border-teal-100 flex flex-col">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-teal-500 rounded-xl flex items-center justify-center text-white">
              <Lightbulb className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-teal-900">Health Tips</h3>
          </div>
          <div className="space-y-4 flex-1">
            {healthTips.map((tip, i) => (
              <div key={i} className="flex gap-3">
                <div className="w-1.5 h-1.5 bg-teal-400 rounded-full mt-2 flex-shrink-0" />
                <p className="text-sm text-teal-800 leading-relaxed">{tip}</p>
              </div>
            ))}
          </div>
          <button className="mt-8 w-full py-4 bg-white rounded-2xl font-bold text-teal-600 shadow-sm hover:shadow-md transition-all">
            More Tips
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-6"><h3 className="text-xl font-bold text-slate-800">Recent Vitals</h3><button onClick={() => navigate('/tracker')} className="text-teal-600 font-bold text-sm">View All</button></div>
          <div className="space-y-4">
            {metrics.length > 0 ? metrics.map((m) => (
              <div key={m.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                <div className="flex items-center gap-3"><div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm"><Activity className="w-5 h-5 text-slate-400" /></div><div><div className="text-sm font-bold text-slate-700 capitalize">{m.type.replace('_', ' ')}</div><div className="text-xs text-slate-400">{new Date(m.timestamp).toLocaleDateString()}</div></div></div>
                <div className="text-lg font-bold text-slate-800">{m.value} <span className="text-xs text-slate-400">{m.unit}</span></div>
              </div>
            )) : <div className="text-center py-8 text-slate-400">No vitals recorded yet.</div>}
          </div>
        </div>
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-6"><h3 className="text-xl font-bold text-slate-800">Consultations</h3><button onClick={() => navigate('/consultations')} className="text-teal-600 font-bold text-sm">History</button></div>
          <div className="space-y-4">
            {consultations.length > 0 ? consultations.map((c) => (
              <div key={c.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                <div className="flex items-center gap-3"><div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm"><Clock className="w-5 h-5 text-slate-400" /></div><div><div className="text-sm font-bold text-slate-700 truncate max-w-[150px]">{c.symptoms}</div><div className="text-xs text-slate-400">{new Date(c.timestamp).toLocaleDateString()}</div></div></div>
                <div className={cn("px-3 py-1 rounded-full text-xs font-bold uppercase", c.status === 'completed' ? "bg-green-100 text-green-600" : c.status === 'in-progress' ? "bg-orange-100 text-orange-600" : "bg-slate-200 text-slate-600")}>{c.status}</div>
              </div>
            )) : <div className="text-center py-8 text-slate-400">No consultations yet.</div>}
          </div>
        </div>
      </div>
    </div>
  );
}
