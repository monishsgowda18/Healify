import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { motion } from 'motion/react';
import { 
  Activity, 
  ArrowLeft, 
  Plus, 
  Calendar, 
  TrendingUp, 
  Thermometer, 
  Weight, 
  Droplets,
  Heart,
  FileUp,
  FileText,
  Trash2,
  Mic
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { storage } from '../services/storageService';
import { HealthMetric, HealthFile } from '../types';
import { cn } from '../lib/utils';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { VoiceInput } from '../components/VoiceInput';

export default function HealthTracker() {
  const { user } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [metrics, setMetrics] = useState<HealthMetric[]>([]);
  const [files, setFiles] = useState<HealthFile[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [newMetric, setNewMetric] = useState({
    type: 'weight' as HealthMetric['type'],
    value: '',
    unit: 'kg'
  });

  useEffect(() => {
    fetchMetrics();
    fetchFiles();
  }, [user]);

  const fetchMetrics = async () => {
    const all = await storage.getAll('metrics');
    setMetrics(all.filter(m => m.userId === user?.id).sort((a, b) => a.timestamp - b.timestamp));
  };

  const fetchFiles = async () => {
    const all = await storage.getAll('files');
    setFiles(all.filter(f => f.userId === user?.id).sort((a, b) => b.timestamp - a.timestamp));
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    setIsUploading(true);
    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const healthFile: HealthFile = {
          id: Date.now().toString(),
          userId: user.id,
          name: file.name,
          type: file.type,
          url: reader.result as string,
          timestamp: Date.now(),
        };
        await storage.setItem('files', healthFile);
        fetchFiles();
      };
      reader.readAsDataURL(file);
    } catch (error) {
      console.error(error);
    } finally {
      setIsUploading(false);
    }
  };

  const handleDeleteFile = async (id: string) => {
    await storage.deleteItem('files', id);
    fetchFiles();
  };

  const handleAddMetric = async () => {
    if (!newMetric.value) return;
    const metric: HealthMetric = {
      id: Date.now().toString(),
      userId: user!.id,
      type: newMetric.type,
      value: parseFloat(newMetric.value),
      unit: newMetric.unit,
      timestamp: Date.now(),
    };
    await storage.setItem('metrics', metric);
    setShowAddModal(false);
    setNewMetric({ type: 'weight', value: '', unit: 'kg' });
    fetchMetrics();
  };

  const metricTypes = [
    { id: 'weight', label: 'Weight', unit: 'kg', icon: Weight, color: 'text-blue-500', bg: 'bg-blue-50' },
    { id: 'blood_sugar', label: 'Blood Sugar', unit: 'mg/dL', icon: Droplets, color: 'text-orange-500', bg: 'bg-orange-50' },
    { id: 'temperature', label: 'Temperature', unit: '°C', icon: Thermometer, color: 'text-yellow-500', bg: 'bg-yellow-50' },
    { id: 'steps', label: 'Steps', unit: 'steps', icon: TrendingUp, color: 'text-green-500', bg: 'bg-green-50' },
    { id: 'sleep', label: 'Sleep', unit: 'hrs', icon: Activity, color: 'text-purple-500', bg: 'bg-purple-50' },
  ];

  const chartData = metrics.filter(m => m.type === newMetric.type).map(m => ({
    time: new Date(m.timestamp).toLocaleDateString(),
    value: m.value
  }));

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-white rounded-xl shadow-sm">
            <ArrowLeft className="w-6 h-6 text-slate-600" />
          </button>
          <h1 className="text-3xl font-bold text-slate-800">{t('health_tracker')}</h1>
        </div>
        <button 
          onClick={() => setShowAddModal(true)}
          className="bg-teal-500 text-white px-6 py-3 rounded-2xl font-bold flex items-center gap-2 shadow-lg shadow-teal-200 hover:bg-teal-600 transition-all"
        >
          <Plus className="w-5 h-5" /> Log Metric
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {metricTypes.map(type => {
          const last = metrics.filter(m => m.type === type.id).pop();
          return (
            <div key={type.id} className="bg-white p-4 rounded-3xl shadow-sm border border-slate-100">
              <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center mb-3", type.bg)}>
                <type.icon className={cn("w-5 h-5", type.color)} />
              </div>
              <div className="text-xs text-slate-400 font-medium uppercase">{type.label}</div>
              <div className="text-xl font-bold text-slate-800">
                {last ? last.value : '--'} <span className="text-xs text-slate-400">{type.unit}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Chart Section */}
      <div className="bg-white p-8 rounded-[40px] shadow-sm border border-slate-100">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h3 className="text-xl font-bold text-slate-800">Health Trends</h3>
            <p className="text-slate-400 text-sm">Visualizing your {newMetric.type.replace('_', ' ')} over time</p>
          </div>
          <select 
            className="bg-slate-50 border-none rounded-xl px-4 py-2 text-sm font-bold text-slate-600 outline-none"
            value={newMetric.type}
            onChange={e => setNewMetric({...newMetric, type: e.target.value as any})}
          >
            {metricTypes.map(t => <option key={t.id} value={t.id}>{t.label}</option>)}
          </select>
        </div>

        <div className="h-[300px] w-full">
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#14b8a6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#14b8a6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="time" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <Tooltip 
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Area type="monotone" dataKey="value" stroke="#14b8a6" strokeWidth={3} fillOpacity={1} fill="url(#colorValue)" />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex items-center justify-center text-slate-400 bg-slate-50 rounded-3xl border-2 border-dashed border-slate-100">
              No data points for this metric yet.
            </div>
          )}
        </div>
      </div>

      {/* File Upload Section */}
      <div className="bg-white p-8 rounded-[40px] shadow-sm border border-slate-100">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-xl font-bold text-slate-800">Medical Records</h3>
            <p className="text-slate-400 text-sm">Upload and manage your health documents</p>
          </div>
          <label className="cursor-pointer bg-slate-50 text-slate-600 px-6 py-3 rounded-2xl font-bold flex items-center gap-2 hover:bg-slate-100 transition-all">
            <FileUp className="w-5 h-5" />
            <span>Upload File</span>
            <input type="file" className="hidden" onChange={handleFileUpload} disabled={isUploading} />
          </label>
        </div>

        {files.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {files.map(file => (
              <div key={file.id} className="p-4 bg-slate-50 rounded-2xl flex items-center justify-between group">
                <div className="flex items-center gap-3 overflow-hidden">
                  <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center flex-shrink-0">
                    <FileText className="w-5 h-5 text-teal-500" />
                  </div>
                  <div className="overflow-hidden">
                    <div className="text-sm font-bold text-slate-800 truncate">{file.name}</div>
                    <div className="text-[10px] text-slate-400">{new Date(file.timestamp).toLocaleDateString()}</div>
                  </div>
                </div>
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <a href={file.url} download={file.name} className="p-2 hover:bg-white rounded-lg text-slate-400 hover:text-teal-500">
                    <FileUp className="w-4 h-4" />
                  </a>
                  <button onClick={() => handleDeleteFile(file.id)} className="p-2 hover:bg-white rounded-lg text-slate-400 hover:text-red-500">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-12 flex flex-col items-center justify-center text-slate-400 bg-slate-50 rounded-3xl border-2 border-dashed border-slate-100">
            <FileText className="w-12 h-12 mb-3 opacity-20" />
            <p>No documents uploaded yet.</p>
          </div>
        )}
      </div>

      {/* Add Metric Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-[40px] p-8 max-w-md w-full shadow-2xl"
          >
            <h3 className="text-2xl font-bold text-slate-800 mb-6">Log Health Metric</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Metric Type</label>
                <div className="grid grid-cols-3 gap-2">
                  {metricTypes.map(t => (
                    <button
                      key={t.id}
                      onClick={() => setNewMetric({...newMetric, type: t.id as any, unit: t.unit})}
                      className={cn(
                        "p-3 rounded-2xl text-xs font-bold transition-all border-2",
                        newMetric.type === t.id ? "bg-teal-50 border-teal-500 text-teal-700" : "bg-slate-50 border-transparent text-slate-500"
                      )}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>
              <div className="relative">
                <label className="block text-sm font-medium text-slate-700 mb-2">Value ({newMetric.unit})</label>
                <div className="relative">
                  <input
                    type="number"
                    step="0.1"
                    className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:border-teal-500 outline-none text-xl font-bold pr-14"
                    placeholder="0.0"
                    value={newMetric.value}
                    onChange={e => setNewMetric({...newMetric, value: e.target.value})}
                  />
                  <VoiceInput 
                    onResult={(text) => setNewMetric({...newMetric, value: text.replace(/[^\d.]/g, '')})} 
                    className="absolute right-3 top-2.5"
                    size={28}
                  />
                </div>
              </div>
            </div>
            <div className="flex gap-3 mt-8">
              <button 
                onClick={() => setShowAddModal(false)}
                className="flex-1 py-4 rounded-2xl font-bold text-slate-500 hover:bg-slate-50"
              >
                Cancel
              </button>
              <button 
                onClick={handleAddMetric}
                className="flex-1 py-4 rounded-2xl bg-teal-500 text-white font-bold shadow-lg shadow-teal-200 hover:bg-teal-600"
              >
                Save Metric
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
