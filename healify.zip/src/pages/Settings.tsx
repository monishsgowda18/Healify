import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { motion } from 'motion/react';
import { 
  Settings as SettingsIcon, 
  ArrowLeft, 
  User, 
  Bell, 
  Moon, 
  Sun, 
  Volume2, 
  Languages, 
  Shield,
  Trash2,
  ChevronRight
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { cn } from '../lib/utils';
import { LANGUAGES } from '../constants';

export default function Settings() {
  const { user, logout } = useAuth();
  const { t, language, setLanguage } = useLanguage();
  const navigate = useNavigate();
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(user?.voiceAssistantEnabled || false);

  const sections = [
    {
      title: 'Personal Information',
      icon: User,
      items: [
        { label: 'Edit Profile', value: user?.name, action: () => {} },
        { label: 'Contact Number', value: user?.contactNumber, action: () => {} },
      ]
    },
    {
      title: 'Language & Accessibility',
      icon: Languages,
      items: [
        { label: 'App Language', value: LANGUAGES.find(l => l.code === language)?.native, action: () => {} },
        { label: 'Voice Assistant', value: voiceEnabled ? 'Enabled' : 'Disabled', action: () => setVoiceEnabled(!voiceEnabled) },
      ]
    },
    {
      title: 'Security & Privacy',
      icon: Shield,
      items: [
        { label: 'Change Password', value: '••••••••', action: () => {} },
        { label: 'Guardian Access', value: 'Manage', action: () => navigate('/guardian-portal') },
      ]
    }
  ];

  return (
    <div className="p-6 max-w-2xl mx-auto space-y-8">
      <div className="flex items-center gap-4">
        <button onClick={() => navigate(-1)} className="p-2 hover:bg-white rounded-xl shadow-sm">
          <ArrowLeft className="w-6 h-6 text-slate-600" />
        </button>
        <h1 className="text-3xl font-bold text-slate-800">{t('settings')}</h1>
      </div>

      <div className="space-y-6">
        {/* Appearance Card */}
        <div className="bg-white p-6 rounded-[32px] shadow-sm border border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center">
              {isDarkMode ? <Moon className="w-6 h-6 text-slate-600" /> : <Sun className="w-6 h-6 text-yellow-500" />}
            </div>
            <div>
              <h3 className="font-bold text-slate-800">Dark Mode</h3>
              <p className="text-xs text-slate-400">Adjust app appearance</p>
            </div>
          </div>
          <button 
            onClick={() => setIsDarkMode(!isDarkMode)}
            className={cn(
              "w-14 h-8 rounded-full p-1 transition-all",
              isDarkMode ? "bg-teal-500" : "bg-slate-200"
            )}
          >
            <motion.div 
              animate={{ x: isDarkMode ? 24 : 0 }}
              className="w-6 h-6 bg-white rounded-full shadow-sm"
            />
          </button>
        </div>

        {/* Sections */}
        {sections.map((section) => (
          <div key={section.title} className="space-y-3">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider ml-4">{section.title}</h3>
            <div className="bg-white rounded-[32px] shadow-sm border border-slate-100 overflow-hidden">
              {section.items.map((item, idx) => (
                <button
                  key={item.label}
                  onClick={item.action}
                  className={cn(
                    "w-full px-6 py-5 flex items-center justify-between hover:bg-slate-50 transition-colors text-left",
                    idx !== section.items.length - 1 && "border-b border-slate-50"
                  )}
                >
                  <div>
                    <div className="text-sm font-medium text-slate-500">{item.label}</div>
                    <div className="font-bold text-slate-800">{item.value}</div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-slate-300" />
                </button>
              ))}
            </div>
          </div>
        ))}

        {/* Danger Zone */}
        <div className="pt-4">
          <button 
            onClick={logout}
            className="w-full p-6 bg-red-50 rounded-[32px] border border-red-100 flex items-center justify-between group"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm">
                <Trash2 className="w-6 h-6 text-red-500" />
              </div>
              <div className="text-left">
                <h3 className="font-bold text-red-800">Logout</h3>
                <p className="text-xs text-red-400">Sign out of your account</p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-red-300 group-hover:text-red-500 transition-colors" />
          </button>
        </div>
      </div>
    </div>
  );
}
