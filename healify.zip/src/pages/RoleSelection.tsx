import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { ROLES } from '../constants';
import { motion } from 'motion/react';
import { useNavigate } from 'react-router-dom';
import * as Icons from 'lucide-react';

export default function RoleSelection() {
  const { t } = useLanguage();
  const navigate = useNavigate();

  const handleSelect = (roleId: string) => {
    navigate(`/register?role=${roleId}`);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-2xl w-full"
      >
        <h1 className="text-3xl font-bold text-slate-800 text-center mb-8">{t('select_role')}</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {ROLES.map((role) => {
            const Icon = (Icons as any)[role.icon];
            return (
              <button
                key={role.id}
                onClick={() => handleSelect(role.id)}
                className="bg-white p-6 rounded-3xl shadow-sm border-2 border-transparent hover:border-teal-500 hover:shadow-md transition-all flex flex-col items-center text-center group"
              >
                <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center mb-4 group-hover:bg-teal-50 transition-colors">
                  <Icon className="w-8 h-8 text-slate-400 group-hover:text-teal-500" />
                </div>
                <span className="text-lg font-bold text-slate-700">{role.label}</span>
              </button>
            );
          })}
        </div>

        <div className="mt-8 text-center">
          <button 
            onClick={() => navigate('/login')}
            className="text-teal-600 font-semibold hover:underline"
          >
            Already have an account? Login
          </button>
        </div>
      </motion.div>
    </div>
  );
}
