import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { motion } from 'motion/react';
import { 
  Stethoscope, 
  Users, 
  FileText, 
  CheckCircle2, 
  Clock, 
  AlertCircle,
  Search,
  Filter,
  ChevronRight,
  Pill,
  Package,
  Mic
} from 'lucide-react';
import { storage } from '../services/storageService';
import { Consultation, Prescription } from '../types';
import { cn } from '../lib/utils';
import { VoiceInput } from '../components/VoiceInput';

export default function ProfessionalDashboard() {
  const { user } = useAuth();
  const { t } = useLanguage();
  const [consultations, setConsultations] = useState<Consultation[]>([]);
  const [prescriptions, setPrescriptions] = useState<Prescription[]>([]);
  const [activeTab, setActiveTab] = useState('pending');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetchData();
  }, [user]);

  const fetchData = async () => {
    const allCons = await storage.getAll('consultations');
    setConsultations(allCons);
    const allPres = await storage.getAll('prescriptions');
    setPrescriptions(allPres);
  };

  const isDoctor = user?.role === 'doctor';
  const isNurse = user?.role === 'nurse';
  const isPharmacy = user?.role === 'pharmacy';

  const stats = [
    { label: 'Pending', value: consultations.filter(c => c.status === 'pending').length, icon: Clock, color: 'text-orange-500', bg: 'bg-orange-50' },
    { label: 'Completed', value: consultations.filter(c => c.status === 'completed').length, icon: CheckCircle2, color: 'text-green-500', bg: 'bg-green-50' },
    { label: 'Total Patients', value: 12, icon: Users, color: 'text-blue-500', bg: 'bg-blue-50' },
  ];

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">Welcome, {isDoctor ? 'Dr. ' : ''}{user?.name}</h1>
          <p className="text-slate-500">You have {consultations.filter(c => c.status === 'pending').length} pending tasks today.</p>
        </div>
        {!user?.isVerified && (
          <div className="bg-orange-50 border border-orange-100 px-4 py-2 rounded-2xl flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-orange-500" />
            <span className="text-sm font-bold text-orange-700">Certification Pending Verification</span>
          </div>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {stats.map(stat => (
          <div key={stat.label} className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex items-center gap-4">
            <div className={cn("w-14 h-14 rounded-2xl flex items-center justify-center", stat.bg)}>
              <stat.icon className={cn("w-7 h-7", stat.color)} />
            </div>
            <div>
              <div className="text-sm font-medium text-slate-400">{stat.label}</div>
              <div className="text-2xl font-black text-slate-800">{stat.value}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Main Content */}
      <div className="bg-white rounded-[40px] shadow-sm border border-slate-100 overflow-hidden">
        <div className="border-b border-slate-100 p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex gap-2 p-1 bg-slate-50 rounded-2xl w-fit">
            {['pending', 'completed', 'all'].map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={cn(
                  "px-6 py-2 rounded-xl text-sm font-bold transition-all capitalize",
                  activeTab === tab ? "bg-white text-teal-600 shadow-sm" : "text-slate-400 hover:text-slate-600"
                )}
              >
                {tab}
              </button>
            ))}
          </div>
          <div className="flex gap-2">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
              <input 
                type="text" 
                placeholder="Search patient..." 
                className="pl-9 pr-4 py-2 bg-slate-50 border border-slate-100 rounded-xl text-sm outline-none focus:border-teal-500"
              />
            </div>
            <button className="p-2 bg-slate-50 rounded-xl text-slate-400 hover:text-slate-600">
              <Filter className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="divide-y divide-slate-50">
          {consultations.length > 0 ? consultations.filter(c => activeTab === 'all' || c.status === activeTab).map((c) => (
            <div key={c.id} className="p-6 hover:bg-slate-50 transition-colors flex items-center justify-between group">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-slate-100 rounded-2xl flex items-center justify-center text-slate-400">
                  <FileText className="w-6 h-6" />
                </div>
                <div>
                  <div className="font-bold text-slate-800">Consultation #{c.id.slice(-4)}</div>
                  <div className="text-sm text-slate-500 truncate max-w-[200px]">{c.symptoms}</div>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[10px] bg-slate-200 px-2 py-0.5 rounded-full font-bold text-slate-600 uppercase">Patient ID: {c.patientId}</span>
                    <span className="text-[10px] text-slate-400">{new Date(c.timestamp).toLocaleString()}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className={cn(
                  "px-3 py-1 rounded-full text-[10px] font-bold uppercase",
                  c.status === 'completed' ? "bg-green-100 text-green-600" : "bg-orange-100 text-orange-600"
                )}>
                  {c.status}
                </div>
                <button className="p-2 bg-white border border-slate-100 rounded-xl text-slate-400 group-hover:text-teal-600 group-hover:border-teal-200 transition-all">
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          )) : (
            <div className="p-20 text-center text-slate-400">No consultations found.</div>
          )}
        </div>
      </div>

      {/* Pharmacy Specific Section */}
      {isPharmacy && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white p-8 rounded-[40px] shadow-sm border border-slate-100">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-slate-800">Medication Inventory</h3>
              <button className="text-teal-600 font-bold text-sm">Manage</button>
            </div>
            <div className="space-y-4">
              {['Paracetamol', 'Amoxicillin', 'Metformin'].map(med => (
                <div key={med} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm">
                      <Package className="w-5 h-5 text-slate-400" />
                    </div>
                    <span className="font-bold text-slate-700">{med}</span>
                  </div>
                  <span className="text-green-600 font-bold text-sm">In Stock</span>
                </div>
              ))}
            </div>
          </div>
          <div className="bg-white p-8 rounded-[40px] shadow-sm border border-slate-100">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-slate-800">Prescription Queue</h3>
              <button className="text-teal-600 font-bold text-sm">View All</button>
            </div>
            <div className="space-y-4">
              {prescriptions.slice(0, 3).map(p => (
                <div key={p.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm">
                      <Pill className="w-5 h-5 text-slate-400" />
                    </div>
                    <div>
                      <div className="text-sm font-bold text-slate-700">Prescription #{p.id.slice(-4)}</div>
                      <div className="text-[10px] text-slate-400">{new Date(p.timestamp).toLocaleDateString()}</div>
                    </div>
                  </div>
                  <button className="px-4 py-1.5 bg-teal-500 text-white rounded-lg text-xs font-bold">Fulfill</button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
