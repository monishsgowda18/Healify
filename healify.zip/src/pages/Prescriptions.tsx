import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { motion } from 'motion/react';
import { 
  Pill, 
  ArrowLeft, 
  Download, 
  Play, 
  Clock, 
  MapPin, 
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { storage } from '../services/storageService';
import { Prescription } from '../types';
import { cn } from '../lib/utils';

export default function Prescriptions() {
  const { user } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [prescriptions, setPrescriptions] = useState<Prescription[]>([]);

  useEffect(() => {
    fetchPrescriptions();
  }, [user]);

  const fetchPrescriptions = async () => {
    const all = await storage.getAll('prescriptions');
    setPrescriptions(all.filter(p => p.patientId === user?.id).sort((a, b) => b.timestamp - a.timestamp));
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-8">
      <div className="flex items-center gap-4">
        <button onClick={() => navigate(-1)} className="p-2 hover:bg-white rounded-xl shadow-sm">
          <ArrowLeft className="w-6 h-6 text-slate-600" />
        </button>
        <h1 className="text-3xl font-bold text-slate-800">{t('prescriptions')}</h1>
      </div>

      <div className="space-y-6">
        {prescriptions.length > 0 ? prescriptions.map((p) => (
          <motion.div 
            key={p.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-[40px] shadow-sm border border-slate-100 overflow-hidden"
          >
            <div className="p-8">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-orange-50 rounded-2xl flex items-center justify-center">
                    <Pill className="w-8 h-8 text-orange-500" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-slate-800">Prescription #{p.id.slice(-4)}</h3>
                    <div className="text-sm text-slate-400 flex items-center gap-2">
                      <Clock className="w-3 h-3" /> {new Date(p.timestamp).toLocaleDateString()}
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button className="p-3 bg-slate-50 text-slate-500 rounded-xl hover:bg-slate-100 transition-colors">
                    <Play className="w-5 h-5" />
                  </button>
                  <button className="p-3 bg-teal-50 text-teal-600 rounded-xl hover:bg-teal-100 transition-colors">
                    <Download className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="space-y-4">
                {p.medications.map((med, idx) => (
                  <div key={idx} className="p-4 bg-slate-50 rounded-2xl border border-slate-100 flex items-center justify-between">
                    <div>
                      <div className="font-bold text-slate-800">{med.name}</div>
                      <div className="text-sm text-slate-500">{med.dosage} • {med.frequency} • {med.duration}</div>
                    </div>
                    <div className="flex items-center gap-2 text-green-600 font-bold text-xs uppercase">
                      <CheckCircle2 className="w-4 h-4" /> Available
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 p-4 bg-blue-50 rounded-2xl border border-blue-100">
                <h4 className="font-bold text-blue-800 text-sm mb-1 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4" /> Instructions
                </h4>
                <p className="text-sm text-blue-600 leading-relaxed">{p.instructions}</p>
              </div>
            </div>

            <div className="bg-slate-50 px-8 py-4 flex items-center justify-between border-t border-slate-100">
              <div className="flex items-center gap-2 text-slate-500 text-sm">
                <MapPin className="w-4 h-4" />
                <span>Ready for pickup at <b>City Pharmacy</b></span>
              </div>
              <button className="text-teal-600 font-bold text-sm hover:underline">View Pharmacy Map</button>
            </div>
          </motion.div>
        )) : (
          <div className="text-center py-20 bg-white rounded-[40px] border border-slate-100">
            <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Pill className="w-10 h-10 text-slate-300" />
            </div>
            <h3 className="text-xl font-bold text-slate-800">No active prescriptions</h3>
            <p className="text-slate-500 mt-2">Your prescriptions will appear here once issued by a doctor.</p>
          </div>
        )}
      </div>
    </div>
  );
}
