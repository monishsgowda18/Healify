import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Mic, User, Bot, ArrowLeft, Search, History, MessageSquare, Camera, Image as ImageIcon, X, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { geminiService } from '../services/geminiService';
import { voiceService } from '../services/voiceService';
import ReactMarkdown from 'react-markdown';
import { storage } from '../services/storageService';
import { cn } from '../lib/utils';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  image?: string;
}

export default function AIChat() {
  const { user } = useAuth();
  const { t, language } = useLanguage();
  const navigate = useNavigate();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [selectedImage, setSelectedImage] = useState<{ data: string, mimeType: string } | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchHistory = async () => {
    const all = await storage.getAll('chats');
    setMessages(all.sort((a, b) => a.timestamp - b.timestamp));
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  const clearHistory = async () => {
    const all = await storage.getAll('chats');
    for (const msg of all) {
      await storage.deleteItem('chats', msg.id);
    }
    setMessages([]);
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async (text: string = input) => {
    if (!text.trim() && !selectedImage) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: text,
      timestamp: Date.now(),
      image: selectedImage ? `data:${selectedImage.mimeType};base64,${selectedImage.data}` : undefined
    };

    setMessages(prev => [...prev, userMsg]);
    await storage.setItem('chats', userMsg);
    setInput('');
    const currentImage = selectedImage;
    setSelectedImage(null);
    setIsTyping(true);

    try {
      // Convert messages to Gemini history format
      const history = messages.map(m => ({
        role: m.role === 'user' ? 'user' as const : 'model' as const,
        parts: [{ text: m.content }]
      }));

      const response = await geminiService.chat(text, history, language, currentImage || undefined);
      
      // Extract voice summary if present
      const parts = response.split('VOICE_SUMMARY: ');
      const mainContent = parts[0].trim();
      const voiceSummary = parts[1]?.trim() || mainContent;

      const assistantMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: mainContent,
        timestamp: Date.now(),
      };
      setMessages(prev => [...prev, assistantMsg]);
      await storage.setItem('chats', assistantMsg);
      
      if (user?.voiceAssistantEnabled) {
        voiceService.speak(voiceSummary);
      }
    } catch (error) {
      console.error(error);
      // Offline fallback
      if (!navigator.onLine) {
        const offlineMsg: Message = {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: "I'm currently offline, but I can still help with basic symptoms. For example, fever and cough might indicate a flu. Please consult a doctor when you're back online.",
          timestamp: Date.now(),
        };
        setMessages(prev => [...prev, offlineMsg]);
        await storage.setItem('chats', offlineMsg);
      }
    } finally {
      setIsTyping(false);
    }
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = (reader.result as string).split(',')[1];
        setSelectedImage({
          data: base64String,
          mimeType: file.type
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleVoiceInput = async () => {
    setIsListening(true);
    try {
      const text = await voiceService.listen();
      handleSend(text);
    } catch (error) {
      console.error(error);
    } finally {
      setIsListening(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-64px)] bg-slate-50">
      {/* Chat Header */}
      <div className="bg-white border-b border-slate-100 px-6 py-4 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-slate-50 rounded-xl">
            <ArrowLeft className="w-6 h-6 text-slate-600" />
          </button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center">
              <Bot className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <h2 className="font-bold text-slate-800">AI Health Assistant</h2>
              <div className="flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                <span className="text-xs text-slate-400">Online & Ready</span>
              </div>
            </div>
          </div>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={clearHistory}
            className="p-2 hover:bg-slate-50 rounded-xl text-slate-400"
            title="Clear History"
          >
            <Trash2 className="w-5 h-5" />
          </button>
          <button className="p-2 hover:bg-slate-50 rounded-xl text-slate-400">
            <History className="w-5 h-5" />
          </button>
          <button className="p-2 hover:bg-slate-50 rounded-xl text-slate-400">
            <Search className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Messages Area */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar"
      >
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-center max-w-sm mx-auto">
            <div className="w-20 h-20 bg-purple-50 rounded-3xl flex items-center justify-center mb-6">
              <MessageSquare className="w-10 h-10 text-purple-400" />
            </div>
            <h3 className="text-xl font-bold text-slate-800">How can I help you today?</h3>
            <p className="text-slate-500 mt-2">Describe your symptoms or ask any health-related question.</p>
            <div className="grid grid-cols-1 gap-2 mt-8 w-full">
              {['I have a headache', 'What are the symptoms of malaria?', 'How to treat a minor burn?'].map(q => (
                <button 
                  key={q}
                  onClick={() => handleSend(q)}
                  className="p-3 bg-white border border-slate-100 rounded-xl text-sm text-slate-600 hover:border-purple-200 hover:bg-purple-50 transition-all"
                >
                  "{q}"
                </button>
              ))}
            </div>
          </div>
        )}

        <AnimatePresence>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={cn(
                "flex gap-4 max-w-[85%]",
                msg.role === 'user' ? "ml-auto flex-row-reverse" : ""
              )}
            >
              <div className={cn(
                "w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 shadow-sm",
                msg.role === 'user' ? "bg-teal-500 text-white" : "bg-white text-purple-600"
              )}>
                {msg.role === 'user' ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5" />}
              </div>
              <div className={cn(
                "p-4 rounded-2xl shadow-sm",
                msg.role === 'user' 
                  ? "bg-teal-500 text-white rounded-tr-none" 
                  : "bg-white text-slate-700 rounded-tl-none border border-slate-100"
              )}>
                {msg.image && (
                  <img 
                    src={msg.image} 
                    alt="Attached symptom" 
                    className="max-w-full rounded-lg mb-3 border border-white/20"
                    referrerPolicy="no-referrer"
                  />
                )}
                <div className="prose prose-sm max-w-none">
                  <ReactMarkdown>{msg.content}</ReactMarkdown>
                </div>
                <div className={cn(
                  "text-[10px] mt-2 opacity-50",
                  msg.role === 'user' ? "text-right" : ""
                )}>
                  {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {isTyping && (
          <div className="flex gap-4">
            <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm text-purple-600">
              <Bot className="w-5 h-5" />
            </div>
            <div className="bg-white p-4 rounded-2xl rounded-tl-none border border-slate-100 shadow-sm">
              <div className="flex gap-1">
                <motion.div animate={{ opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 1 }} className="w-1.5 h-1.5 bg-slate-400 rounded-full" />
                <motion.div animate={{ opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 1, delay: 0.2 }} className="w-1.5 h-1.5 bg-slate-400 rounded-full" />
                <motion.div animate={{ opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 1, delay: 0.4 }} className="w-1.5 h-1.5 bg-slate-400 rounded-full" />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="bg-white border-t border-slate-100 p-4 sm:p-6">
        <div className="max-w-4xl mx-auto space-y-4">
          {selectedImage && (
            <div className="relative inline-block">
              <img 
                src={`data:${selectedImage.mimeType};base64,${selectedImage.data}`} 
                alt="Selected" 
                className="w-20 h-20 object-cover rounded-xl border-2 border-purple-200"
              />
              <button 
                onClick={() => setSelectedImage(null)}
                className="absolute -top-2 -right-2 p-1 bg-red-500 text-white rounded-full shadow-md"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          )}
          
          <div className="flex items-center gap-3">
            <input 
              type="file" 
              accept="image/*" 
              className="hidden" 
              ref={fileInputRef}
              onChange={handleImageSelect}
            />
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="p-4 rounded-2xl bg-slate-100 text-slate-500 hover:bg-slate-200 transition-all shadow-sm"
            >
              <ImageIcon className="w-6 h-6" />
            </button>
            <button 
              onClick={handleVoiceInput}
              className={cn(
                "p-4 rounded-2xl transition-all shadow-lg",
                isListening ? "bg-red-500 text-white animate-pulse" : "bg-slate-100 text-slate-500 hover:bg-slate-200"
              )}
            >
              <Mic className="w-6 h-6" />
            </button>
            <div className="flex-1 relative">
              <input
                type="text"
                placeholder="Type your message..."
                className="w-full pl-6 pr-14 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:bg-white focus:border-purple-300 focus:ring-4 focus:ring-purple-50 outline-none transition-all"
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyPress={e => e.key === 'Enter' && handleSend()}
              />
              <button 
                onClick={() => handleSend()}
                disabled={!input.trim() && !selectedImage}
                className="absolute right-2 top-2 p-3 bg-purple-600 text-white rounded-xl shadow-lg shadow-purple-200 hover:bg-purple-700 transition-all disabled:opacity-50 disabled:shadow-none"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
