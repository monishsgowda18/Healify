import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { motion } from 'motion/react';
import { 
  Plus, 
  ArrowLeft, 
  Camera, 
  Activity, 
  FileText, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  Calendar,
  Mic
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { storage } from '../services/storageService';
import { geminiService } from '../services/geminiService';
import { Consultation } from '../types';
import { cn } from '../lib/utils';
import { VoiceInput } from '../components/VoiceInput';

export default function ConsultationManagement() {
  const { user } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [consultations, setConsultations] = useState<Consultation[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [formData, setFormData] = useState({
    symptoms: '',
    vitals: {
      temp: ''
    }
  });

  const [selectedCons, setSelectedCons] = useState<Consultation | null>(null);

  useEffect(() => {
    fetchConsultations();
  }, [user]);

  const fetchConsultations = async () => {
    const all = await storage.getAll('consultations');
    setConsultations(all.filter(c => c.patientId === user?.id).sort((a, b) => b.timestamp - a.timestamp));
  };

  const handleVoiceResult = (field: string, text: string) => {
    if (field === 'symptoms') {
      setFormData(prev => ({ ...prev, symptoms: text }));
    } else if (field === 'temp') {
      setFormData(prev => ({ ...prev, vitals: { ...prev.vitals, temp: text.replace(/[^\d.]/g, '') } }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const newCons: Consultation = {
      id: Date.now().toString(),
      patientId: user!.id,
      status: 'pending',
      symptoms: formData.symptoms,
      vitals: {
        temperature: parseFloat(formData.vitals.temp)
      },
      images: [],
      timestamp: Date.now()
    };
    
    await storage.setItem('consultations', newCons);
    setIsAdding(false);
    setFormData({ symptoms: '', vitals: { temp: '' } });
    fetchConsultations();

    // Trigger AI Solution automatically
    try {
      const aiResponse = await geminiService.getConsultation(newCons.symptoms, newCons.vitals, []);
      const updatedCons: Consultation = {
        ...newCons,
        status: 'completed',
        diagnosis: aiResponse.diagnosis,
        prescription: aiResponse.prescription.map((p: any) => ({
          name: p.name,
          dosage: p.dosage,
          frequency: p.frequency,
          duration: p.duration
        })),
        instructions: aiResponse.instructions
      };
      await storage.setItem('consultations', updatedCons);
      
      // Also create a prescription record
      await storage.setItem('prescriptions', {
        id: Date.now().toString(),
        patientId: user!.id,
        medications: updatedCons.prescription!,
        instructions: updatedCons.instructions!,
        timestamp: Date.now(),
        isAIGenerated: true,
        consultationId: updatedCons.id
      });

      fetchConsultations();
    } catch (error) {
      console.error("AI Consultation Error:", error);
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-2 hover:bg-white rounded-xl shadow-sm">
            <ArrowLeft className="w-6 h-6 text-slate-600" />
          </button>
          <h1 className="text-3xl font-bold text-slate-800">Consultations</h1>
        </div>
        {!isAdding && (
          <button 
            onClick={() => setIsAdding(true)}
            className="bg-teal-500 text-white px-6 py-3 rounded-2xl font-bold flex items-center gap-2 shadow-lg shadow-teal-200"
          >
            <Plus className="w-5 h-5" /> New Request
          </button>
        )}
      </div>

      {isAdding ? (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-8 rounded-[40px] shadow-xl border border-slate-100"
        >
          <h2 className="text-2xl font-bold text-slate-800 mb-6">Request Consultation</h2>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="relative">
              <label className="block text-sm font-medium text-slate-700 mb-2">Describe your symptoms</label>
              <div className="relative">
                <textarea
                  required
                  rows={4}
                  className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:border-teal-500 outline-none pr-14"
                  placeholder="e.g. I have a persistent cough and fever for 3 days..."
                  value={formData.symptoms}
                  onChange={e => setFormData({...formData, symptoms: e.target.value})}
                />
                <VoiceInput 
                  onResult={(text) => handleVoiceResult('symptoms', text)} 
                  className="absolute right-3 top-3"
                  size={24}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="relative">
                <label className="block text-sm font-medium text-slate-700 mb-2">Temperature (°C)</label>
                <div className="relative">
                  <input
                    type="number"
                    step="0.1"
                    className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-slate-100 focus:border-teal-500 outline-none pr-14"
                    value={formData.vitals.temp}
                    onChange={e => setFormData({...formData, vitals: {...formData.vitals, temp: e.target.value}})}
                  />
                  <VoiceInput 
                    onResult={(text) => handleVoiceResult('temp', text)} 
                    className="absolute right-3 top-2.5"
                    size={24}
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Upload Photo (Optional)</label>
                <button type="button" className="w-full px-6 py-4 rounded-2xl bg-slate-50 border border-dashed border-slate-300 flex items-center justify-center gap-2 text-slate-500">
                  <Camera className="w-5 h-5" /> Add Image
                </button>
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <button 
                type="button"
                onClick={() => setIsAdding(false)}
                className="flex-1 py-4 rounded-2xl font-bold text-slate-500 hover:bg-slate-50"
              >
                Cancel
              </button>
              <button 
                type="submit"
                className="flex-1 py-4 rounded-2xl bg-teal-500 text-white font-bold shadow-lg shadow-teal-200 hover:bg-teal-600"
              >
                Submit Request
              </button>
            </div>
          </form>
        </motion.div>
      ) : (
        <div className="space-y-4">
          {consultations.length > 0 ? consultations.map((c) => (
            <div key={c.id} className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-start gap-4">
                <div className={cn(
                  "w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0",
                  c.status === 'completed' ? "bg-green-50 text-green-600" : "bg-orange-50 text-orange-600"
                )}>
                  {c.status === 'completed' ? <CheckCircle2 className="w-6 h-6" /> : <Clock className="w-6 h-6" />}
                </div>
                <div>
                  <h3 className="font-bold text-slate-800 truncate max-w-[200px]">{c.symptoms}</h3>
                  <div className="flex items-center gap-3 mt-1">
                    <span className="text-xs text-slate-400 flex items-center gap-1">
                      <Calendar className="w-3 h-3" /> {new Date(c.timestamp).toLocaleDateString()}
                    </span>
                    <span className={cn(
                      "text-[10px] font-bold uppercase px-2 py-0.5 rounded-full",
                      c.status === 'completed' ? "bg-green-100 text-green-600" : "bg-orange-100 text-orange-600"
                    )}>
                      {c.status}
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right hidden sm:block">
                  <div className="text-xs text-slate-400">Vitals Recorded</div>
                  <div className="text-sm font-bold text-slate-600">Temp: {c.vitals.temperature}°C</div>
                </div>
                <button 
                  onClick={() => setSelectedCons(c)}
                  className="px-6 py-2 rounded-xl border border-slate-200 font-bold text-slate-600 hover:bg-slate-50 transition-colors"
                >
                  View Details
                </button>
              </div>
            </div>
          )) : (
            <div className="text-center py-20 bg-white rounded-[40px] border border-slate-100">
              <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileText className="w-10 h-10 text-slate-300" />
              </div>
              <h3 className="text-xl font-bold text-slate-800">No consultations found</h3>
              <p className="text-slate-500 mt-2">Submit your first consultation request to get started.</p>
            </div>
          )}
        </div>
      )}

      {/* Details Modal */}
      {selectedCons && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white w-full max-w-2xl rounded-[40px] shadow-2xl overflow-hidden max-h-[90vh] flex flex-col"
          >
            <div className="p-8 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-slate-800">Consultation Details</h2>
                <p className="text-slate-400 text-sm">ID: {selectedCons.id}</p>
              </div>
              <button 
                onClick={() => setSelectedCons(null)}
                className="p-2 hover:bg-slate-50 rounded-xl"
              >
                <Plus className="w-6 h-6 text-slate-400 rotate-45" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-8 space-y-8 custom-scrollbar">
              {/* Symptoms & Vitals */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Symptoms</h4>
                  <p className="text-slate-700 bg-slate-50 p-4 rounded-2xl border border-slate-100">{selectedCons.symptoms}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Vitals</h4>
                  <div className="bg-orange-50 p-3 rounded-xl border border-orange-100">
                    <div className="text-[10px] text-orange-400 font-bold uppercase">Temp</div>
                    <div className="text-lg font-bold text-orange-600">{selectedCons.vitals.temperature}°C</div>
                  </div>
                </div>
              </div>

              {/* AI Solution */}
              {selectedCons.status === 'completed' ? (
                <div className="space-y-6">
                  <div className="p-6 bg-teal-50 rounded-3xl border border-teal-100">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-10 h-10 bg-teal-500 rounded-xl flex items-center justify-center text-white">
                        <CheckCircle2 className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="font-bold text-teal-900">AI Assessment Complete</h4>
                        <p className="text-teal-600 text-xs">Generated by Healify AI Assistant</p>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div>
                        <h5 className="text-sm font-bold text-teal-800 mb-1">Diagnosis</h5>
                        <p className="text-slate-700 leading-relaxed">{selectedCons.diagnosis}</p>
                      </div>
                      
                      {selectedCons.prescription && selectedCons.prescription.length > 0 && (
                        <div>
                          <h5 className="text-sm font-bold text-teal-800 mb-2">Prescription</h5>
                          <div className="space-y-2">
                            {selectedCons.prescription.map((p, idx) => (
                              <div key={idx} className="bg-white p-3 rounded-xl border border-teal-100 flex justify-between items-center">
                                <div>
                                  <div className="font-bold text-slate-800">{p.name}</div>
                                  <div className="text-xs text-slate-500">{p.dosage} • {p.frequency}</div>
                                </div>
                                <div className="text-xs font-bold text-teal-600">{p.duration}</div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      <div>
                        <h5 className="text-sm font-bold text-teal-800 mb-1">Instructions</h5>
                        <p className="text-slate-600 text-sm leading-relaxed">{selectedCons.instructions}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-12 text-center bg-slate-50 rounded-3xl border border-dashed border-slate-200">
                  <Clock className="w-12 h-12 text-slate-300 mx-auto mb-4 animate-pulse" />
                  <h4 className="font-bold text-slate-800">Review in Progress</h4>
                  <p className="text-slate-500 text-sm mt-1">Our AI is analyzing your symptoms. This usually takes less than a minute.</p>
                </div>
              )}
            </div>

            <div className="p-8 bg-slate-50 border-t border-slate-100">
              <button 
                onClick={() => setSelectedCons(null)}
                className="w-full py-4 bg-white border border-slate-200 rounded-2xl font-bold text-slate-600 hover:bg-slate-100 transition-all"
              >
                Close Details
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
