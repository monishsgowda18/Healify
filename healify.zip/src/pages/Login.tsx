import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { Phone, Lock, ArrowRight, Mic } from 'lucide-react';
import { ROLES } from '../constants';
import { VoiceInput } from '../components/VoiceInput';

export default function Login() {
  const { login } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('patient');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await login(phone, role as any);
      navigate('/dashboard');
    } catch (error) {
      alert('Login failed. Please check your credentials.');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full bg-white rounded-3xl shadow-xl overflow-hidden"
      >
        <div className="bg-teal-500 p-8 text-white text-center">
          <div className="w-16 h-16 bg-white/20 rounded-2xl mx-auto flex items-center justify-center mb-4">
            <Lock className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold">Welcome Back</h2>
          <p className="opacity-90">Login to your Healify account</p>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Login as</label>
              <select
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-teal-500 outline-none bg-white"
                value={role}
                onChange={e => setRole(e.target.value)}
              >
                {ROLES.map(r => (
                  <option key={r.id} value={r.id}>{r.label}</option>
                ))}
              </select>
            </div>

            <div className="relative">
              <label className="block text-sm font-medium text-slate-700 mb-1">Phone Number</label>
              <div className="relative">
                <Phone className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                <input
                  type="tel"
                  placeholder="Enter phone number"
                  required
                  className="w-full pl-10 pr-12 py-3 rounded-xl border border-slate-200 focus:border-teal-500 outline-none"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                />
                <VoiceInput 
                  onResult={(text) => setPhone(text.replace(/\s/g, ''))} 
                  className="absolute right-2 top-1.5"
                />
              </div>
            </div>

            <div className="relative">
              <label className="block text-sm font-medium text-slate-700 mb-1">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                <input
                  type="password"
                  placeholder="Enter password"
                  required
                  className="w-full pl-10 pr-12 py-3 rounded-xl border border-slate-200 focus:border-teal-500 outline-none"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                />
                <VoiceInput 
                  onResult={(text) => setPassword(text)} 
                  className="absolute right-2 top-1.5"
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-teal-500 text-white py-4 rounded-xl font-bold text-lg shadow-lg shadow-teal-200 hover:bg-teal-600 transition-all flex items-center justify-center gap-2"
          >
            Login <ArrowRight className="w-5 h-5" />
          </button>

          <div className="text-center">
            <Link to="/role-selection" className="text-teal-600 font-semibold hover:underline">
              Don't have an account? Register
            </Link>
          </div>
        </form>
      </motion.div>
    </div>
  );
}
