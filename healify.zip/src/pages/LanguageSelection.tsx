import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { LANGUAGES } from '../constants';
import { motion } from 'motion/react';
import { useNavigate } from 'react-router-dom';

export default function LanguageSelection() {
  const { setLanguage } = useLanguage();
  const navigate = useNavigate();

  const handleSelect = (code: string) => {
    setLanguage(code);
    navigate('/role-selection');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full bg-white rounded-3xl shadow-xl p-8"
      >
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-teal-500 rounded-2xl mx-auto flex items-center justify-center mb-4 shadow-lg shadow-teal-200">
            <span className="text-white text-4xl font-bold">H</span>
          </div>
          <h1 className="text-3xl font-bold text-slate-800">Healify</h1>
          <p className="text-slate-500 mt-2">Select your preferred language</p>
        </div>

        <div className="grid grid-cols-2 gap-3 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
          {LANGUAGES.map((lang) => (
            <button
              key={lang.code}
              onClick={() => handleSelect(lang.code)}
              className="p-4 rounded-2xl border-2 border-slate-100 hover:border-teal-500 hover:bg-teal-50 transition-all text-left group"
            >
              <div className="text-sm text-slate-400 group-hover:text-teal-600">{lang.name}</div>
              <div className="text-lg font-bold text-slate-700 group-hover:text-teal-700">{lang.native}</div>
            </button>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
