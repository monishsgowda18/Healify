import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BookOpen, 
  Search, 
  ArrowLeft, 
  ChevronRight, 
  Play, 
  FileText,
  Heart,
  Droplets,
  Wind,
  Brain,
  Volume2,
  Mic2
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { cn } from '../lib/utils';
import { voiceService } from '../services/voiceService';

const AUDIO_GUIDES = [
  { id: '1', title: 'Hygiene Basics', duration: '1:20', category: 'General' },
  { id: '2', title: 'Maternal Care Tips', duration: '2:45', category: 'Women' },
  { id: '3', title: 'Managing Fever', duration: '1:50', category: 'Emergency' },
  { id: '4', title: 'Healthy Diet', duration: '3:10', category: 'Lifestyle' },
];

const LIBRARY_DATA = [
  {
    id: 'respiratory',
    title: 'Respiratory Health',
    icon: Wind,
    color: 'bg-blue-50 text-blue-600',
    topics: [
      { title: 'Common Cold & Flu', content: 'Influenza is a viral infection that attacks your respiratory system...' },
      { title: 'Asthma Management', content: 'Asthma is a condition in which your airways narrow and swell...' },
    ]
  },
  {
    id: 'cardio',
    title: 'Heart Health',
    icon: Heart,
    color: 'bg-red-50 text-red-600',
    topics: [
      { title: 'Blood Pressure Control', content: 'High blood pressure is a common condition in which the long-term force of the blood against your artery walls...' },
      { title: 'Healthy Diet for Heart', content: 'Eating a heart-healthy diet is one of the best ways to prevent heart disease...' },
    ]
  },
  {
    id: 'diabetes',
    title: 'Diabetes Care',
    icon: Droplets,
    color: 'bg-orange-50 text-orange-600',
    topics: [
      { title: 'Monitoring Blood Sugar', content: 'Regularly checking your blood sugar levels is a key part of managing diabetes...' },
      { title: 'Insulin Basics', content: 'Insulin is a hormone that allows your body to use sugar (glucose) from carbohydrates...' },
    ]
  },
  {
    id: 'mental',
    title: 'Mental Wellness',
    icon: Brain,
    color: 'bg-purple-50 text-purple-600',
    topics: [
      { title: 'Managing Stress', content: 'Stress is a natural physical and mental reaction to life experiences...' },
      { title: 'Better Sleep Habits', content: 'Sleep is as important to our health as eating, drinking, and breathing...' },
    ]
  }
];

export default function MedicalLibrary() {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [selectedTopic, setSelectedTopic] = useState<any>(null);

  const filteredData = LIBRARY_DATA.filter(cat => 
    cat.title.toLowerCase().includes(search.toLowerCase()) ||
    cat.topics.some(t => t.title.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-8">
      <div className="flex items-center gap-4">
        <button onClick={() => navigate(-1)} className="p-2 hover:bg-white rounded-xl shadow-sm">
          <ArrowLeft className="w-6 h-6 text-slate-600" />
        </button>
        <h1 className="text-3xl font-bold text-slate-800">{t('medical_library')}</h1>
      </div>

      <div className="relative">
        <Search className="absolute left-4 top-4 w-6 h-6 text-slate-400" />
        <input
          type="text"
          placeholder="Search for diseases, symptoms, or health tips..."
          className="w-full pl-14 pr-6 py-4 rounded-2xl bg-white border border-slate-100 shadow-sm focus:border-teal-500 outline-none transition-all text-lg"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </div>

      {/* Audio Guides Section */}
      <div className="bg-gradient-to-br from-teal-500 to-emerald-600 p-8 rounded-[40px] text-white shadow-xl shadow-teal-100">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
            <Volume2 className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-bold">Audio Health Guides</h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {AUDIO_GUIDES.map(guide => (
            <button 
              key={guide.id}
              onClick={() => voiceService.speak(`Playing audio guide: ${guide.title}`)}
              className="p-4 bg-white/10 hover:bg-white/20 rounded-2xl border border-white/10 flex items-center justify-between transition-all group"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-teal-600 group-hover:scale-110 transition-transform">
                  <Play className="w-5 h-5 fill-current" />
                </div>
                <div className="text-left">
                  <div className="font-bold text-sm">{guide.title}</div>
                  <div className="text-[10px] opacity-60">{guide.category} • {guide.duration}</div>
                </div>
              </div>
              <Mic2 className="w-4 h-4 opacity-40" />
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredData.map((cat) => (
          <div key={cat.id} className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
            <div className={cn("p-6 flex items-center gap-4", cat.color)}>
              <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm">
                <cat.icon className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold">{cat.title}</h3>
            </div>
            <div className="p-2">
              {cat.topics.map((topic, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedTopic(topic)}
                  className="w-full p-4 flex items-center justify-between hover:bg-slate-50 rounded-2xl transition-colors group"
                >
                  <div className="flex items-center gap-3">
                    <FileText className="w-5 h-5 text-slate-400" />
                    <span className="font-medium text-slate-700">{topic.title}</span>
                  </div>
                  <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-teal-500 transition-colors" />
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      <AnimatePresence>
        {selectedTopic && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="bg-white rounded-[40px] p-8 max-w-2xl w-full max-h-[80vh] overflow-y-auto relative"
            >
              <button 
                onClick={() => setSelectedTopic(null)}
                className="absolute right-6 top-6 p-2 hover:bg-slate-100 rounded-full"
              >
                <ArrowLeft className="w-6 h-6 text-slate-400" />
              </button>
              
              <h2 className="text-3xl font-bold text-slate-800 mb-6 pr-12">{selectedTopic.title}</h2>
              
              <div className="prose prose-slate max-w-none">
                <p className="text-lg text-slate-600 leading-relaxed">{selectedTopic.content}</p>
                <div className="mt-8 p-6 bg-teal-50 rounded-3xl border border-teal-100">
                  <h4 className="font-bold text-teal-800 flex items-center gap-2 mb-2">
                    <Play className="w-4 h-4 fill-current" /> Listen to Audio Version
                  </h4>
                  <p className="text-sm text-teal-600">The voice assistant can read this article for you in your preferred language.</p>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
