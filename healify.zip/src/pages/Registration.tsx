import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion } from 'motion/react';
import { UserRole } from '../types';
import { Upload, Shield, User, Phone, MapPin, Calendar, Lock, Mic } from 'lucide-react';
import { VoiceInput } from '../components/VoiceInput';

export default function Registration() {
  const [searchParams] = useSearchParams();
  const role = (searchParams.get('role') as UserRole) || 'patient';
  const { register } = useAuth();
  const { t, language } = useLanguage();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: '',
    age: '',
    gender: 'male',
    location: '',
    contactNumber: '',
    password: '',
    certification: null as File | null,
  });

  const handleVoiceResult = (field: keyof typeof formData, text: string) => {
    setFormData(prev => ({ ...prev, [field]: text }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await register({
        ...formData,
        age: parseInt(formData.age),
        role,
        language,
      });
      navigate('/dashboard');
    } catch (error) {
      alert('Registration failed');
    }
  };

  const isProfessional = ['doctor', 'nurse', 'pharmacy'].includes(role);

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        className="max-w-md w-full bg-white rounded-3xl shadow-xl overflow-hidden"
      >
        <div className="bg-teal-500 p-8 text-white">
          <h2 className="text-2xl font-bold">Create Account</h2>
          <p className="opacity-90 capitalize">Registering as {role}</p>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-4">
          <div className="space-y-4">
            <div className="relative">
              <User className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
              <input
                type="text"
                placeholder="Full Name"
                required
                className="w-full pl-10 pr-12 py-3 rounded-xl border border-slate-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 outline-none transition-all"
                value={formData.name}
                onChange={e => setFormData({...formData, name: e.target.value})}
              />
              <VoiceInput 
                onResult={(text) => handleVoiceResult('name', text)} 
                className="absolute right-2 top-1.5"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="relative">
                <Calendar className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
                <input
                  type="number"
                  placeholder="Age"
                  required
                  className="w-full pl-10 pr-12 py-3 rounded-xl border border-slate-200 focus:border-teal-500 outline-none"
                  value={formData.age}
                  onChange={e => setFormData({...formData, age: e.target.value})}
                />
                <VoiceInput 
                  onResult={(text) => handleVoiceResult('age', text.replace(/\D/g, ''))} 
                  className="absolute right-2 top-1.5"
                />
              </div>
              <select
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-teal-500 outline-none bg-white"
                value={formData.gender}
                onChange={e => setFormData({...formData, gender: e.target.value})}
              >
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div className="relative">
              <MapPin className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
              <input
                type="text"
                placeholder="Location"
                required
                className="w-full pl-10 pr-12 py-3 rounded-xl border border-slate-200 focus:border-teal-500 outline-none"
                value={formData.location}
                onChange={e => setFormData({...formData, location: e.target.value})}
              />
              <VoiceInput 
                onResult={(text) => handleVoiceResult('location', text)} 
                className="absolute right-2 top-1.5"
              />
            </div>

            <div className="relative">
              <Phone className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
              <input
                type="tel"
                placeholder="Contact Number"
                required
                className="w-full pl-10 pr-12 py-3 rounded-xl border border-slate-200 focus:border-teal-500 outline-none"
                value={formData.contactNumber}
                onChange={e => setFormData({...formData, contactNumber: e.target.value})}
              />
              <VoiceInput 
                onResult={(text) => handleVoiceResult('contactNumber', text.replace(/\s/g, ''))} 
                className="absolute right-2 top-1.5"
              />
            </div>

            <div className="relative">
              <Lock className="absolute left-3 top-3 w-5 h-5 text-slate-400" />
              <input
                type="password"
                placeholder="Password"
                required
                className="w-full pl-10 pr-12 py-3 rounded-xl border border-slate-200 focus:border-teal-500 outline-none"
                value={formData.password}
                onChange={e => setFormData({...formData, password: e.target.value})}
              />
              <VoiceInput 
                onResult={(text) => handleVoiceResult('password', text)} 
                className="absolute right-2 top-1.5"
              />
            </div>

            {isProfessional && (
              <div className="p-4 border-2 border-dashed border-slate-200 rounded-xl bg-slate-50">
                <label className="flex flex-col items-center cursor-pointer">
                  <Upload className="w-8 h-8 text-slate-400 mb-2" />
                  <span className="text-sm font-medium text-slate-600">Upload Professional Certification</span>
                  <span className="text-xs text-slate-400 mt-1">PDF, JPG or PNG (Max 5MB)</span>
                  <input 
                    type="file" 
                    className="hidden" 
                    required 
                    onChange={e => setFormData({...formData, certification: e.target.files?.[0] || null})}
                  />
                </label>
                {formData.certification && (
                  <div className="mt-2 text-xs text-teal-600 font-medium text-center">
                    Selected: {formData.certification.name}
                  </div>
                )}
              </div>
            )}
          </div>

          <button
            type="submit"
            className="w-full bg-teal-500 text-white py-4 rounded-xl font-bold text-lg shadow-lg shadow-teal-200 hover:bg-teal-600 transition-all active:scale-95"
          >
            {isProfessional ? 'Register & Submit for Verification' : 'Register Now'}
          </button>
        </form>
      </motion.div>
    </div>
  );
}
