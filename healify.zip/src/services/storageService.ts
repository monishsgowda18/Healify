import { openDB, IDBPDatabase } from 'idb';

const DB_NAME = 'healify_db';
const DB_VERSION = 3;

export const initDB = async () => {
  return openDB(DB_NAME, DB_VERSION, {
    upgrade(db) {
      if (!db.objectStoreNames.contains('users')) {
        db.createObjectStore('users', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('metrics')) {
        db.createObjectStore('metrics', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('consultations')) {
        db.createObjectStore('consultations', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('prescriptions')) {
        db.createObjectStore('prescriptions', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('files')) {
        db.createObjectStore('files', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('guardians')) {
        db.createObjectStore('guardians', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('chats')) {
        db.createObjectStore('chats', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('sync_queue')) {
        db.createObjectStore('sync_queue', { keyPath: 'id', autoIncrement: true });
      }
    },
  });
};

export class StorageService {
  private db: Promise<IDBPDatabase>;

  constructor() {
    this.db = initDB();
  }

  async setItem(storeName: string, item: any) {
    const db = await this.db;
    return db.put(storeName, item);
  }

  async getItem(storeName: string, id: string) {
    const db = await this.db;
    return db.get(storeName, id);
  }

  async getAll(storeName: string) {
    const db = await this.db;
    return db.getAll(storeName);
  }

  async deleteItem(storeName: string, id: string) {
    const db = await this.db;
    return db.delete(storeName, id);
  }
}

export const storage = new StorageService();
