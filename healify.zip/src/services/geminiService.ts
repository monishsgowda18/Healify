import { GoogleGenAI, Type } from "@google/genai";

const apiKey = process.env.GEMINI_API_KEY || "";
const ai = new GoogleGenAI({ apiKey });

export const geminiService = {
  async getConsultation(symptoms: string, vitals: any, history: any[]) {
    const model = "gemini-3-flash-preview";
    
    const systemInstruction = `
      You are a professional AI Medical Assistant for Healify.
      Your goal is to provide accurate, concise, and structured medical guidance for rural patients.
      STRICT CONSTRAINTS:
      - NEVER output long lists of irrelevant health keywords or "filler" text.
      - Each text field MUST be under 100 words.
      - Be direct and professional.
      - Output ONLY valid JSON.
    `;

    const prompt = `
      Patient Symptoms: ${symptoms}
      Patient Vitals: ${JSON.stringify(vitals)}
      Medical History: ${JSON.stringify(history)}

      Provide a structured response in JSON format. 
      IMPORTANT: Keep each text field very concise (max 100 words) to avoid truncation.
      
      Include:
      1. diagnosis: A brief diagnosis or assessment.
      2. disease_info: Description of the suspected condition.
      3. prescription: List of recommended medications with dosage, frequency, and duration.
      4. instructions: Detailed usage instructions and side effects.
      5. dos_and_donts: List of do's and don'ts for this condition.
      6. lifestyle_recommendations: Dietary and lifestyle advice.
      7. warning_signs: When to seek emergency care.
      8. alternatives: Alternative medications if primary ones are unavailable.
    `;

    try {
      const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: {
          systemInstruction,
          responseMimeType: "application/json",
          maxOutputTokens: 4096, // Increased to allow for complete JSON if slightly long
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              diagnosis: { type: Type.STRING, description: "Max 50 words" },
              disease_info: { type: Type.STRING, description: "Max 100 words" },
              prescription: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING, description: "Medication name only" },
                    dosage: { type: Type.STRING },
                    frequency: { type: Type.STRING },
                    duration: { type: Type.STRING },
                    alternatives: { type: Type.ARRAY, items: { type: Type.STRING } }
                  }
                }
              },
              instructions: { type: Type.STRING, description: "Max 150 words" },
              dos_and_donts: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Max 10 items" },
              lifestyle_recommendations: { type: Type.STRING, description: "Max 100 words" },
              warning_signs: { type: Type.STRING, description: "Max 100 words" },
            },
            required: ["diagnosis", "disease_info", "prescription", "instructions"]
          }
        }
      });

      const text = response.text?.trim() || "{}";
      
      try {
        return JSON.parse(text);
      } catch (parseError) {
        console.error("JSON Parse Error:", parseError, "Response Text:", text);
        throw new Error("Failed to parse AI response. The response may have been truncated or malformed.");
      }
    } catch (error) {
      console.error("Gemini Error:", error);
      throw error;
    }
  },
  async chat(message: string, history: any[], language: string = 'en', image?: { data: string, mimeType: string }) {
    const model = "gemini-3-flash-preview";
    
    const systemInstruction = `
      You are a professional AI Health Assistant for Healify.
      Provide helpful, accurate, and concise health information in ${language}.
      If asked for a diagnosis, advise the user to consult a professional but provide general possibilities.
      If an image is provided, analyze it carefully for medical symptoms (like rashes, wounds, etc.).
      Keep responses under 200 words.
      Use simple language suitable for rural communities.
      
      CRITICAL: After your main response, provide a one-sentence summary for voice output, prefixed with "VOICE_SUMMARY: ".
    `;

    try {
      const userParts: any[] = [{ text: message }];
      if (image) {
        userParts.push({
          inlineData: {
            data: image.data,
            mimeType: image.mimeType
          }
        });
      }

      const response = await ai.models.generateContent({
        model,
        contents: [
          ...history,
          { role: 'user', parts: userParts }
        ],
        config: {
          systemInstruction,
          maxOutputTokens: 1024,
        }
      });

      return response.text || "I'm sorry, I couldn't process that request.";
    } catch (error) {
      console.error("Gemini Chat Error:", error);
      throw error;
    }
  }
};
