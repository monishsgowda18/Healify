import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { LanguageProvider } from './contexts/LanguageContext';
import LanguageSelection from './pages/LanguageSelection';
import RoleSelection from './pages/RoleSelection';
import Registration from './pages/Registration';
import Login from './pages/Login';
import PatientDashboard from './pages/PatientDashboard';
import AIChat from './pages/AIChat';
import HealthTracker from './pages/HealthTracker';
import MedicalLibrary from './pages/MedicalLibrary';
import ConsultationManagement from './pages/ConsultationManagement';
import Prescriptions from './pages/Prescriptions';
import GuardianPortal from './pages/GuardianPortal';
import Settings from './pages/Settings';
import ProfessionalDashboard from './pages/ProfessionalDashboard';
import { Header } from './components/Header';

const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isLoading } = useAuth();
  const location = useLocation();
  
  if (isLoading) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  if (!user) return <Navigate to="/language-selection" />;

  const isPro = ['doctor', 'nurse', 'pharmacy'].includes(user.role);
  if (isPro && location.pathname === '/dashboard') {
    return <Navigate to="/pro-dashboard" />;
  }
  if (!isPro && location.pathname === '/pro-dashboard') {
    return <Navigate to="/dashboard" />;
  }
  
  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      <main>{children}</main>
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <LanguageProvider>
        <Router>
          <Routes>
            <Route path="/language-selection" element={<LanguageSelection />} />
            <Route path="/role-selection" element={<RoleSelection />} />
            <Route path="/register" element={<Registration />} />
            <Route path="/login" element={<Login />} />
            
            <Route path="/dashboard" element={
              <ProtectedRoute>
                <PatientDashboard />
              </ProtectedRoute>
            } />
            
            <Route path="/ai-chat" element={
              <ProtectedRoute>
                <AIChat />
              </ProtectedRoute>
            } />

            <Route path="/tracker" element={
              <ProtectedRoute>
                <HealthTracker />
              </ProtectedRoute>
            } />

            <Route path="/library" element={
              <ProtectedRoute>
                <MedicalLibrary />
              </ProtectedRoute>
            } />

            <Route path="/consultations" element={
              <ProtectedRoute>
                <ConsultationManagement />
              </ProtectedRoute>
            } />

            <Route path="/consultation/new" element={
              <ProtectedRoute>
                <ConsultationManagement />
              </ProtectedRoute>
            } />

            <Route path="/prescriptions" element={
              <ProtectedRoute>
                <Prescriptions />
              </ProtectedRoute>
            } />

            <Route path="/guardians" element={
              <ProtectedRoute>
                <GuardianPortal />
              </ProtectedRoute>
            } />

            <Route path="/settings" element={
              <ProtectedRoute>
                <Settings />
              </ProtectedRoute>
            } />

            <Route path="/pro-dashboard" element={
              <ProtectedRoute>
                <ProfessionalDashboard />
              </ProtectedRoute>
            } />
            
            <Route path="/" element={<Navigate to="/dashboard" />} />
          </Routes>
        </Router>
      </LanguageProvider>
    </AuthProvider>
  );
}
